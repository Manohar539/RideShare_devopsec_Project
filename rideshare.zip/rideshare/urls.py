from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("rides.urls")),
    path('accounts/', include('django.contrib.auth.urls')),
    path('users/', include('users.urls')),
    path('bookings/', include('bookings.urls')),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])